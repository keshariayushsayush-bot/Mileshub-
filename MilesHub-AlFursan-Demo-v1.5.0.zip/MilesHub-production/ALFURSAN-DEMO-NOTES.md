# AlFursan demo edition (MilesHub 1.5.0)

This is an independent, clearly labelled demo marketplace. It is not the official SAUDIA/AlFursan website and has no airline API integration.

The dashboard adds an interactive miles-to-INR estimate based on a user-entered rate. It must not be represented as a live airline balance, redemption quote, available award seat, ticket, transfer confirmation, or proof of fulfilment.

Never collect airline passwords, OTPs, payment credentials, or pretend to verify real AlFursan membership records. Use the official SAUDIA channels for real account access and redemption.
