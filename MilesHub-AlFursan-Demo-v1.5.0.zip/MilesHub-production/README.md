# MilesHub 1.5.0 — AlFursan demo marketplace update

MilesHub is an independent AlFursan-focused demo marketplace (not affiliated with SAUDIA) built as a Node.js + Express + PostgreSQL application for customer and seller accounts, seller-submitted miles listings, admin review, order requests, stock reservation, order tracking, printable order summaries, WhatsApp sharing, and clearly labelled sandbox payment simulations.

**This is deployable application code, not a live website.** It does not connect to airline loyalty accounts, verify a live airline balance, transfer miles, process card/UPI payments, or prove that a resale is permitted. Only enable a programme after checking its current rules and obtaining any required authorization. An order status is an operational record, not proof of payment or miles fulfilment.

## AlFursan-focused UI update\n\n- AlFursan-themed dashboard labels and customer-facing positioning without copying SAUDIA branding or implying official status\n- Prominent non-affiliation and demo-data notices\n- Interactive miles-to-INR estimate calculator using seller-entered demo rates; not an airline redemption quote\n- Existing customer/seller/admin workflows, PostgreSQL storage, moderated listings, sandbox checkout and order tracking retained\n\n## Included in this release

- Customer and seller self-registration with email verification (Resend)
- Admin and seller account provisioning from secure server commands
- Password hashing (bcrypt), PostgreSQL-backed sessions, secure cookies, session rotation
- CSRF token checks for state-changing authenticated requests, same-origin checks, Helmet headers, and authentication rate limits
- Password reset by one-time, expiring email link
- Role-separated customer, seller, and admin access
- Admin seller-verification workflow and listing moderation
- Seller attestation that they control the listed miles and have checked transfer/resale permission
- Marketplace listings with airline/programme, miles quantity, INR price per 1,000, and availability
- Public listings only after seller verification, seller attestation, and admin approval
- Transactional stock reservation to reduce overselling
- Sandbox checkout simulation with unique DEMO references; it never contacts a payment provider or transfers money
- Order history and controlled status transitions; cancellation restores reserved stock
- Printable order summary (explicitly not a payment receipt/tax invoice) and WhatsApp share link
- Audit log for seller verification, listing moderation, listing changes, order creation, and status changes
- Health endpoint at `/api/health`
- Render Blueprint for a Node web service and PostgreSQL

## Quick start guide

For the phone-friendly Hindi deployment walkthrough, read [`START-HERE-HINDI.md`](START-HERE-HINDI.md).

## Local setup

Requirements: Node.js 20+ and PostgreSQL.

1. Create a PostgreSQL database named `mileshub`.
2. Copy `.env.example` to `.env` and set `DATABASE_URL`, `SESSION_SECRET` (32+ random characters), and `APP_ORIGIN=http://localhost:3000`.
3. Configure a verified Resend sender: `RESEND_API_KEY` and `EMAIL_FROM`.
4. Run `npm install`.
5. Run `npm test` for syntax checks.
6. Run `npm start`; the app creates/updates its database tables on startup.
7. In a separate terminal, create the first administrator: `npm run create-admin`.
8. Sign in as admin. Create seller accounts through public registration (select Seller) or `npm run create-seller`. Verify seller identity and business evidence outside the app before approving them.
9. Sellers can submit listings only after admin seller verification. Listings remain hidden until admin approves them.
10. Customers can register, verify their email, browse approved listings, and submit order requests.

Email verification and password recovery require Resend configuration. Without it, the app will refuse to send those emails rather than pretending the workflow succeeded.

## Deploy to Render

1. Put this folder in a private GitHub repository.
2. Connect the repository to Render and use the included Blueprint (`render.yaml`). Review current resource plans and prices before applying; the Blueprint provisions paid resources.
3. Set `APP_ORIGIN` to the exact final HTTPS origin (no trailing slash), e.g. `https://your-service.onrender.com`.
4. Set `RESEND_API_KEY` and `EMAIL_FROM` to a verified sender.
5. After the first successful deployment/migration, open the service Shell and run `npm run create-admin`. Use a unique, strong password and do not share it in chat or commit it to Git.
6. Check `https://YOUR-DOMAIN/api/health` and confirm `{ "ok": true, "database": "connected" }`.
7. Test customer and seller registration, email delivery, admin moderation, listing visibility, order reservation/cancellation, password recovery, print view, WhatsApp sharing, and mobile screens before inviting users.

## Important launch requirements

- Obtain professional review of company registration, tax, privacy, consumer-protection, payments, and applicable marketplace obligations.
- Check each loyalty programme's current terms. Disable any programme where resale/transfer is prohibited or not authorized. Do not assume all airlines permit the same transaction.
- Verify seller identity and evidence for each listing before approval. The checkbox attestation is not independent proof.
- Add a qualified, jurisdiction-specific Terms of Service, Privacy Policy, Seller Agreement, refund/dispute rules, prohibited-program policy, and support contact before public launch.
- Configure backups and test database restoration; configure monitoring and incident response.
- Connect a payment provider only after merchant approval. Real payment processing is not included. The demo checkout only writes a clearly marked simulated payment record; it must never be represented as a real payment or receipt.
- Add airline fulfilment integrations only through authorized interfaces and only where programme rules permit. Airline APIs/fulfilment are not included in this release.
- Have the deployed app independently security-tested before processing real orders.

## Never collect

- Airline account passwords
- Airline one-time passwords (OTPs)
- Airline recovery codes
- Raw payment-card numbers or CVVs

## Configuration

See `.env.example`. Keep `.env` private. Never place API keys, passwords, database URLs, or other secrets in frontend code or Git.
