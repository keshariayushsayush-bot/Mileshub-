# MilesHub — Start Here (Hindi)

## Is package mein kya ready hai?
- Node.js + Express backend aur PostgreSQL database
- Customer, seller aur admin roles
- Email verification / password reset (Resend configure karna zaroori)
- Seller verification aur listing approval
- Stock reservation, order history, order status, audit log
- Sandbox payment simulation: sirf demo record; koi asli payment nahi hota
- Render Blueprint (`render.yaml`)

**Important:** Yeh deploy karne ke liye tayyar source package hai, live website nahi. Airline account access, live miles balance, miles transfer aur real payment gateway is release mein connected nahi hain. Kisi customer ko demo payment ko real payment/receipt na batayein.

## A. ZIP ko phone ya computer par taiyar karein
1. `MilesHub-1.4.1-DEPLOY-PREP.zip` download karein.
2. ZIP ko Extract/Unzip karein.
3. `MilesHub-production` folder kholein. GitHub par ZIP nahi, is folder ke ANDAR ki files/folders upload karni hain.
4. `.env` ya kisi password/API key wali file upload na karein. `.env.example` safe template hai.

## B. GitHub repository
1. https://github.com par login karein.
2. `+` → `New repository`.
3. Name `MilesHub`, visibility `Private`, phir `Create repository`.
4. `Add file` → `Upload files`.
5. Extracted `MilesHub-production` ke andar ki saari files/folders select karein. `public`, `scripts`, `server.js`, `package.json`, `render.yaml` sab hone chahiye.
6. `Commit changes` karein.

## C. Render Blueprint deploy
1. https://dashboard.render.com/ kholein aur GitHub connect/authorize karein.
2. `New` → `Blueprint` chunein.
3. Private `MilesHub` repository select karein.
4. Render ko `render.yaml` detect karna chahiye. Agar detect na ho, deploy na karein; pehle repository ke root mein `render.yaml` hona verify karein.
5. Resource plans aur estimated charges review karein. Current Blueprint mein `starter` web service aur `basic-256mb` PostgreSQL plan hai; yeh free setup nahi maana jana chahiye. Charges samajhkar hi `Apply` dabayein.
6. `APP_ORIGIN` mein deploy hone ke baad milne wala exact HTTPS domain set karein (trailing slash ke bina).
7. `RESEND_API_KEY` aur `EMAIL_FROM` set karein. Resend sender/domain pehle verify hona chahiye.
8. Apply/deploy complete hone ka wait karein.

## D. Admin account
1. Render service ke Shell mein jaayein.
2. `npm run create-admin` chalayein.
3. Prompt par admin name, email aur strong password enter karein. Password chat ya GitHub par share na karein.
4. Admin login karke seller verification aur listing approvals kare.

## E. Website test
- `https://YOUR-DOMAIN/api/health` kholein; database connected hona chahiye.
- Customer registration + verification email + login test karein.
- Seller registration + verification + admin approval test karein.
- Listing create/approve, customer order, cancellation/stock restore test karein.
- Demo payment ko sirf sandbox test samjhein; yeh order ko paid nahi banata.
- Password reset, mobile layout, WhatsApp share aur print summary test karein.

## Agar website start na ho
Render → MilesHub service → `Logs` kholein aur latest error ka screenshot/share karein. Secret values, API keys, passwords, database URL ya verification codes screenshot mein visible na hon.

## Public launch se pehle
Business/legal review, applicable airline programme rules and authorization, seller due diligence, privacy/terms/refund policy, approved payment provider integration, authorized fulfilment route, backups, monitoring, and independent security testing complete karein. Jab tak ye complete na hon, public real transactions advertise na karein.
