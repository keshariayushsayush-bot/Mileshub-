require('dotenv').config();
const {Pool}=require('pg');
const bcrypt=require('bcryptjs');
const readline=require('readline');
const rl=readline.createInterface({input:process.stdin,output:process.stdout});
const ask=q=>new Promise(resolve=>rl.question(q,resolve));
(async()=>{
  const name=(await ask('Admin name: ')).trim();
  const email=(await ask('Admin email: ')).trim().toLowerCase();
  const password=await ask('Admin password (12+ characters): ');
  rl.close();
  if(name.length<2 || !/^\S+@\S+\.\S+$/.test(email) || password.length<12 || password.length>72) throw new Error('Invalid admin details.');
  if(!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required.');
  const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.NODE_ENV==='production'?{rejectUnauthorized:false}:undefined});
  try {
    const hash=await bcrypt.hash(password,12);
    await pool.query("INSERT INTO users(name,email,password_hash,role,email_verified,seller_verified) VALUES($1,$2,$3,'admin',TRUE,FALSE)",[name,email,hash]);
    console.log('Admin created. Sign in through MilesHub. Keep this account private.');
  } finally {await pool.end();}
})().catch(e=>{console.error(e.message);process.exit(1)});
