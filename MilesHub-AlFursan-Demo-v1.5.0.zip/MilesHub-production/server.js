require("dotenv").config();
const express = require("express");
const session = require("express-session");
const PgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { z } = require("zod");
const crypto = require("crypto");
const path = require("path");

const app = express();
const isProd = process.env.NODE_ENV === "production";
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: isProd ? { rejectUnauthorized: false } : undefined,
  max: 10
});
pool.on('error', err => console.error('Unexpected PostgreSQL pool error:', err));

if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error("SESSION_SECRET must be at least 32 characters");
}
if (isProd && !process.env.APP_ORIGIN) throw new Error("APP_ORIGIN is required in production");

app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'","'unsafe-inline'"], styleSrc: ["'self'","'unsafe-inline'"], imgSrc: ["'self'",'data:'], fontSrc: ["'self'"], objectSrc: ["'none'"], baseUri: ["'self'"], frameAncestors: ["'none'"] } } }));
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(session({
  store: new PgSession({ pool, tableName: "user_sessions", createTableIfMissing: true }),
  name: "mileshub.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, secure: isProd, sameSite: "lax", maxAge: 8 * 60 * 60 * 1000 }
}));

// Cookie-authenticated state changes require same-origin requests and a session CSRF token.
app.use((req, res, next) => {
  if (!["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) return next();
  const expected = process.env.APP_ORIGIN || `http://localhost:${process.env.PORT || 3000}`;
  const origin = req.get("origin");
  if (isProd && !origin) return res.status(403).json({error:'Origin header required.'});
  if (origin && origin !== expected) return res.status(403).json({ error: "Cross-origin request blocked." });
  if (req.path === "/api/auth/login" || req.path === "/api/auth/register" || req.path === "/api/auth/verify-email" || req.path === "/api/auth/forgot-password" || req.path === "/api/auth/reset-password") return next();
  const token = req.get('x-csrf-token');
  if (!req.session.csrfToken || !token || token !== req.session.csrfToken) return res.status(403).json({error:'Security token expired. Refresh the page and try again.'});
  next();
});

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: "draft-7", legacyHeaders: false });
const api = express.Router();

async function migrate() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('admin','seller','customer')),
      email_verified BOOLEAN NOT NULL DEFAULT FALSE,
      seller_verified BOOLEAN NOT NULL DEFAULT FALSE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS email_verifications (
      id BIGSERIAL PRIMARY KEY,
      email TEXT NOT NULL,
      code_hash TEXT NOT NULL,
      expires_at TIMESTAMPTZ NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS email_verifications_email_idx ON email_verifications(email);
    CREATE TABLE IF NOT EXISTS inventory (
      id BIGSERIAL PRIMARY KEY,
      program TEXT NOT NULL,
      miles BIGINT NOT NULL CHECK (miles >= 0),
      price_per_1000 NUMERIC(12,2) NOT NULL CHECK (price_per_1000 > 0),
      status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available','paused')),
      review_status TEXT NOT NULL DEFAULT 'pending' CHECK (review_status IN ('pending','approved','rejected')),
      seller_attested BOOLEAN NOT NULL DEFAULT FALSE,
      seller_id BIGINT REFERENCES users(id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS password_resets (
      id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash TEXT NOT NULL, expires_at TIMESTAMPTZ NOT NULL, used_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS audit_logs (
      id BIGSERIAL PRIMARY KEY, actor_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
      action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT, details JSONB NOT NULL DEFAULT '{}'::jsonb,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS orders (
      id BIGSERIAL PRIMARY KEY,
      public_id TEXT NOT NULL UNIQUE,
      customer_id BIGINT NOT NULL REFERENCES users(id),
      seller_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
      inventory_id BIGINT REFERENCES inventory(id) ON DELETE SET NULL,
      program TEXT NOT NULL,
      miles BIGINT NOT NULL CHECK (miles > 0),
      unit_price NUMERIC(12,2) NOT NULL,
      total NUMERIC(14,2) NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending verification'
        CHECK (status IN ('Pending verification','Payment verified','Fulfillment in progress','Completed','Cancelled')),
      customer_note TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS demo_payments (
      id BIGSERIAL PRIMARY KEY, order_id BIGINT NOT NULL UNIQUE REFERENCES orders(id) ON DELETE CASCADE,
      customer_id BIGINT NOT NULL REFERENCES users(id), amount NUMERIC(14,2) NOT NULL,
      provider TEXT NOT NULL DEFAULT 'MilesHub Sandbox', status TEXT NOT NULL CHECK (status IN ('SIMULATED_SUCCESS','SIMULATED_FAILED')),
      reference TEXT NOT NULL UNIQUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    ALTER TABLE users ADD COLUMN IF NOT EXISTS seller_verified BOOLEAN NOT NULL DEFAULT FALSE;
    ALTER TABLE users DROP CONSTRAINT IF EXISTS users_role_check;
    ALTER TABLE users ADD CONSTRAINT users_role_check CHECK (role IN ('admin','seller','customer'));
    ALTER TABLE inventory ADD COLUMN IF NOT EXISTS review_status TEXT NOT NULL DEFAULT 'pending';
    ALTER TABLE inventory ADD COLUMN IF NOT EXISTS seller_attested BOOLEAN NOT NULL DEFAULT FALSE;
    ALTER TABLE inventory DROP CONSTRAINT IF EXISTS inventory_review_status_check;
    ALTER TABLE inventory ADD CONSTRAINT inventory_review_status_check CHECK (review_status IN ('pending','approved','rejected'));
    ALTER TABLE inventory ADD COLUMN IF NOT EXISTS seller_id BIGINT REFERENCES users(id) ON DELETE CASCADE;
    ALTER TABLE orders ADD COLUMN IF NOT EXISTS seller_id BIGINT REFERENCES users(id) ON DELETE SET NULL;
    CREATE INDEX IF NOT EXISTS inventory_public_idx ON inventory(status,review_status,program);
    CREATE INDEX IF NOT EXISTS password_resets_user_idx ON password_resets(user_id,created_at DESC);
    CREATE INDEX IF NOT EXISTS audit_logs_created_idx ON audit_logs(created_at DESC);
    CREATE INDEX IF NOT EXISTS inventory_seller_idx ON inventory(seller_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS orders_customer_idx ON orders(customer_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS orders_seller_idx ON orders(seller_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS orders_created_idx ON orders(created_at DESC);
  `);
}

function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Please sign in." });
  next();
}
function requireSeller(req, res, next) {
  if (!req.session.user || req.session.user.role !== "seller") return res.status(403).json({ error: "Seller access required." });
  next();
}
function requireAdmin(req,res,next) {
  if (!req.session.user || req.session.user.role !== 'admin') return res.status(403).json({error:'Administrator access required.'});
  next();
}
async function audit(actorId, action, entityType, entityId, details={}) {
  await pool.query('INSERT INTO audit_logs(actor_id,action,entity_type,entity_id,details) VALUES($1,$2,$3,$4,$5)',[actorId,action,entityType,String(entityId ?? ''),JSON.stringify(details)]);
}
function cleanUser(u) { return { id: u.id, name: u.name, email: u.email, role: u.role }; }
function valid(schema, body) {
  const parsed = schema.safeParse(body);
  if (!parsed.success) throw Object.assign(new Error(parsed.error.issues[0].message), { status: 400 });
  return parsed.data;
}
function asyncRoute(fn) { return (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next); }
function newCode() { return String(crypto.randomInt(100000, 1000000)); }
async function sendVerification(email, code) {
  if (!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM) {
    throw Object.assign(new Error("Email verification is not configured. Contact the site administrator."), { status: 503 });
  }
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: process.env.EMAIL_FROM, to: [email], subject: "Your MilesHub verification code",
      text: `Your MilesHub verification code is ${code}. It expires in 10 minutes. If you did not request this, ignore this email.`
    })
  });
  if (!response.ok) throw Object.assign(new Error("Could not send verification email. Please try again later."), { status: 502 });
}

api.get('/csrf', (req,res) => { if (!req.session.csrfToken) req.session.csrfToken=crypto.randomBytes(32).toString('hex'); res.json({token:req.session.csrfToken}); });

api.get("/health", asyncRoute(async (_req,res) => {
  await pool.query("SELECT 1");
  res.json({ ok: true, database: "connected" });
}));

api.post("/auth/register", authLimiter, asyncRoute(async (req,res) => {
  const data = valid(z.object({
    name: z.string().trim().min(2).max(100),
    email: z.string().trim().email().max(254).transform(v => v.toLowerCase()),
    password: z.string().min(10).max(72),
    role: z.enum(['customer','seller']).optional().default('customer')
  }), req.body);
  const exists = await pool.query("SELECT 1 FROM users WHERE email=$1", [data.email]);
  if (exists.rowCount) return res.status(409).json({ error: "An account with this email already exists." });
  const code = newCode();
  const codeHash = await bcrypt.hash(code, 10);
  await pool.query("DELETE FROM email_verifications WHERE email=$1", [data.email]);
  await pool.query(
    "INSERT INTO email_verifications(email,code_hash,expires_at) VALUES($1,$2,NOW()+INTERVAL '10 minutes')",
    [data.email, codeHash]
  );
  await sendVerification(data.email, code);
  req.session.pendingRegistration = { ...data, codeSentAt: Date.now() };
  res.status(202).json({ message: "Verification code sent to your email." });
}));

api.post("/auth/verify-email", authLimiter, asyncRoute(async (req,res) => {
  const data = valid(z.object({ code: z.string().regex(/^\d{6}$/) }), req.body);
  const pending = req.session.pendingRegistration;
  if (!pending) return res.status(400).json({ error: "Start registration again." });
  const result = await pool.query(
    "SELECT * FROM email_verifications WHERE email=$1 ORDER BY created_at DESC LIMIT 1",
    [pending.email]
  );
  const row = result.rows[0];
  if (!row || row.expires_at < new Date() || row.attempts >= 5) {
    return res.status(400).json({ error: "Code expired or too many attempts. Register again." });
  }
  const match = await bcrypt.compare(data.code, row.code_hash);
  if (!match) {
    await pool.query("UPDATE email_verifications SET attempts=attempts+1 WHERE id=$1", [row.id]);
    return res.status(400).json({ error: "Incorrect verification code." });
  }
  const hash = await bcrypt.hash(pending.password, 12);
  const inserted = await pool.query(
    "INSERT INTO users(name,email,password_hash,role,email_verified) VALUES($1,$2,$3,$4,TRUE) RETURNING id,name,email,role",
    [pending.name, pending.email, hash, pending.role || 'customer']
  );
  await pool.query("DELETE FROM email_verifications WHERE email=$1", [pending.email]);
  delete req.session.pendingRegistration;
  req.session.regenerate(err => {
    if (err) return res.status(500).json({error:'Could not create secure session.'});
    req.session.user = cleanUser(inserted.rows[0]);
    req.session.csrfToken = crypto.randomBytes(32).toString('hex');
    req.session.save(err2 => err2 ? res.status(500).json({error:'Could not save session.'}) : res.status(201).json({user:req.session.user}));
  });
}));

api.post("/auth/login", authLimiter, asyncRoute(async (req,res) => {
  const data = valid(z.object({ email: z.string().email().transform(v => v.toLowerCase()), password: z.string().min(1).max(72) }), req.body);
  const result = await pool.query("SELECT * FROM users WHERE email=$1", [data.email]);
  const user = result.rows[0];
  if (!user || !(await bcrypt.compare(data.password, user.password_hash))) {
    return res.status(401).json({ error: "Email or password is incorrect." });
  }
  if (user.role === "customer" && !user.email_verified) return res.status(403).json({ error: "Verify your email before signing in." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not create secure session." });
    req.session.user = cleanUser(user);
    req.session.csrfToken = crypto.randomBytes(32).toString('hex');
    req.session.save(err2 => err2 ? res.status(500).json({ error: "Could not save session." }) : res.json({ user: req.session.user }));
  });
}));
api.post('/auth/forgot-password', authLimiter, asyncRoute(async(req,res)=>{
  const d=valid(z.object({email:z.string().email().transform(v=>v.toLowerCase())}),req.body);
  const u=await pool.query('SELECT id,email FROM users WHERE email=$1',[d.email]);
  // Always return the same response to avoid account enumeration.
  if(u.rowCount){
    if(!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM) throw Object.assign(new Error('Password recovery email is not configured.'),{status:503});
    const token=crypto.randomBytes(32).toString('hex');
    await pool.query('DELETE FROM password_resets WHERE user_id=$1',[u.rows[0].id]);
    await pool.query("INSERT INTO password_resets(user_id,token_hash,expires_at) VALUES($1,$2,NOW()+INTERVAL '30 minutes')",[u.rows[0].id,crypto.createHash('sha256').update(token).digest('hex')]);
    if(process.env.RESEND_API_KEY && process.env.EMAIL_FROM){
      const origin=process.env.APP_ORIGIN || `http://localhost:${process.env.PORT||3000}`;
      const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${process.env.RESEND_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({from:process.env.EMAIL_FROM,to:[d.email],subject:'Reset your MilesHub password',text:`Use this one-time password reset link within 30 minutes: ${origin}/?reset=${token}`})});
      if(!response.ok) throw Object.assign(new Error('Could not send reset email.'),{status:502});
    }
  }
  res.json({message:'If the account exists, password reset instructions have been sent.'});
}));
api.post('/auth/reset-password', authLimiter, asyncRoute(async(req,res)=>{
  const d=valid(z.object({token:z.string().length(64),password:z.string().min(12).max(72)}),req.body);
  const hash=crypto.createHash('sha256').update(d.token).digest('hex');
  const r=await pool.query('SELECT id,user_id FROM password_resets WHERE token_hash=$1 AND used_at IS NULL AND expires_at>NOW()',[hash]);
  if(!r.rowCount) return res.status(400).json({error:'Reset link is invalid or expired.'});
  const passwordHash=await bcrypt.hash(d.password,12);
  const client=await pool.connect();
  try { await client.query('BEGIN'); await client.query('UPDATE users SET password_hash=$1 WHERE id=$2',[passwordHash,r.rows[0].user_id]); await client.query('UPDATE password_resets SET used_at=NOW() WHERE user_id=$1 AND used_at IS NULL',[r.rows[0].user_id]); await client.query("DELETE FROM user_sessions WHERE sess->'user'->>'id'=$1",[String(r.rows[0].user_id)]); await client.query('COMMIT'); }
  catch(e){await client.query('ROLLBACK');throw e;} finally {client.release();}
  res.json({message:'Password updated. Please sign in again.'});
}));

api.post("/auth/logout", (req,res) => req.session.destroy(() => {
  res.clearCookie("mileshub.sid", { httpOnly: true, secure: isProd, sameSite: "lax" });
  res.status(204).end();
}));
api.get("/auth/me", (req,res) => res.json({ user: req.session.user || null }));

api.get("/inventory", asyncRoute(async (req,res) => {
  const seller = req.session.user?.role === "seller";
  const admin = req.session.user?.role === 'admin';
  const result = await pool.query(
    seller ? "SELECT id,program,miles,price_per_1000,status,review_status,updated_at FROM inventory WHERE seller_id=$1 ORDER BY program" : admin ? "SELECT i.id,i.program,i.miles,i.price_per_1000,i.status,i.review_status,i.seller_attested,i.updated_at,u.email AS seller_email,u.seller_verified FROM inventory i JOIN users u ON u.id=i.seller_id ORDER BY i.created_at DESC" : "SELECT i.id,i.program,i.miles,i.price_per_1000,i.status,i.review_status,i.updated_at FROM inventory i JOIN users u ON u.id=i.seller_id WHERE i.status='available' AND i.review_status='approved' AND u.seller_verified=TRUE AND i.seller_attested=TRUE AND i.miles > 0 ORDER BY i.program",
    seller ? [req.session.user.id] : []
  );
  res.json({ inventory: result.rows });
}));
api.post("/inventory", requireSeller, asyncRoute(async (req,res) => {
  const seller=await pool.query('SELECT seller_verified FROM users WHERE id=$1',[req.session.user.id]);
  if(!seller.rows[0]?.seller_verified) return res.status(403).json({error:'Your seller account must be verified by MilesHub admin before publishing listings.'});
  const d = valid(z.object({ program:z.string().trim().min(2).max(120), miles:z.number().int().min(0).max(1000000000), pricePer1000:z.number().positive().max(1000000), sellerAttested:z.literal(true) }), req.body);
  const r = await pool.query("INSERT INTO inventory(program,miles,price_per_1000,seller_id,review_status,seller_attested) VALUES($1,$2,$3,$4,'pending',$5) RETURNING *", [d.program,d.miles,d.pricePer1000,req.session.user.id,d.sellerAttested]);
  await audit(req.session.user.id,'listing_created','inventory',r.rows[0].id,{program:d.program,miles:d.miles});
  res.status(201).json({ item:r.rows[0] });
}));
api.patch("/inventory/:id", requireSeller, asyncRoute(async (req,res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id)) return res.status(400).json({error:"Invalid inventory id."});
  const seller=await pool.query('SELECT seller_verified FROM users WHERE id=$1',[req.session.user.id]);
  if(!seller.rows[0]?.seller_verified) return res.status(403).json({error:'Your seller account is not currently verified.'});
  const d = valid(z.object({ program:z.string().trim().min(2).max(120), miles:z.number().int().min(0).max(1000000000), pricePer1000:z.number().positive().max(1000000), status:z.enum(["available","paused"]), sellerAttested:z.literal(true) }), req.body);
  const busy=await pool.query("SELECT 1 FROM orders WHERE inventory_id=$1 AND status NOT IN ('Cancelled','Completed') LIMIT 1",[id]);
  if(busy.rowCount) return res.status(409).json({error:'This listing has an active order and cannot be edited yet.'});
  const r = await pool.query("UPDATE inventory SET program=$1,miles=$2,price_per_1000=$3,status=$4,review_status='pending',seller_attested=$5,updated_at=NOW() WHERE id=$6 AND seller_id=$7 RETURNING *", [d.program,d.miles,d.pricePer1000,d.status,d.sellerAttested,id,req.session.user.id]);
  if (!r.rowCount) return res.status(404).json({error:"Listing not found."});
  await audit(req.session.user.id,'listing_updated','inventory',id,{program:d.program,miles:d.miles});
  res.json({item:r.rows[0]});
}));
api.delete("/inventory/:id", requireSeller, asyncRoute(async (req,res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id)) return res.status(400).json({error:"Invalid inventory id."});
  const active=await pool.query("SELECT 1 FROM orders WHERE inventory_id=$1 AND status NOT IN ('Cancelled','Completed') LIMIT 1",[id]);
  if(active.rowCount) return res.status(409).json({error:'This listing has an active order and cannot be deleted.'});
  const r = await pool.query("DELETE FROM inventory WHERE id=$1 AND seller_id=$2", [id,req.session.user.id]);
  if (!r.rowCount) return res.status(404).json({error:"Listing not found."});
  await audit(req.session.user.id,'listing_deleted','inventory',id);
  res.status(204).end();
}));

api.post("/orders", requireAuth, asyncRoute(async (req,res) => {
  const d = valid(z.object({ inventoryId:z.number().int().positive(), miles:z.number().int().positive().max(1000000000), note:z.string().trim().max(500).optional().default("") }), req.body);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const inv = await client.query("SELECT i.* FROM inventory i JOIN users u ON u.id=i.seller_id WHERE i.id=$1 AND i.status='available' AND i.review_status='approved' AND u.seller_verified=TRUE AND i.seller_attested=TRUE FOR UPDATE OF i", [d.inventoryId]);
    if (!inv.rowCount) { await client.query("ROLLBACK"); return res.status(404).json({error:"Listing is not available."}); }
    const item = inv.rows[0];
    if (Number(item.seller_id) === Number(req.session.user.id)) { await client.query('ROLLBACK'); return res.status(400).json({error:'You cannot order your own listing.'}); }
    if (d.miles % 1000 !== 0 || d.miles > Number(item.miles)) { await client.query("ROLLBACK"); return res.status(400).json({error:"Miles must be in 1,000-mile increments and within available stock."}); }
    const unit = Number(item.price_per_1000), total = (d.miles / 1000) * unit;
    const publicId = "MH-" + crypto.randomBytes(5).toString("hex").toUpperCase();
    const order = await client.query(
      "INSERT INTO orders(public_id,customer_id,seller_id,inventory_id,program,miles,unit_price,total,customer_note) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *",
      [publicId,req.session.user.id,item.seller_id,item.id,item.program,d.miles,unit,total,d.note]
    );
    await client.query("UPDATE inventory SET miles=miles-$1,updated_at=NOW() WHERE id=$2", [d.miles,item.id]);
    await client.query("COMMIT");
    await audit(req.session.user.id,'order_created','order',publicId,{inventoryId:item.id,miles:d.miles,total});
    res.status(201).json({order:order.rows[0]});
  } catch(e) { await client.query("ROLLBACK"); throw e; }
  finally { client.release(); }
}));
// Clearly labelled sandbox payment simulation. It never contacts a bank, UPI app, card network, or payment gateway.
api.post('/payments/demo/:orderId', requireAuth, asyncRoute(async (req,res)=>{
  if(req.session.user.role !== 'customer') return res.status(403).json({error:'Only customers can run a demo checkout.'});
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    const found=await client.query('SELECT * FROM orders WHERE public_id=$1 AND customer_id=$2 FOR UPDATE',[req.params.orderId,req.session.user.id]);
    if(!found.rowCount){await client.query('ROLLBACK');return res.status(404).json({error:'Order not found.'});}
    const order=found.rows[0];
    if(order.status==='Cancelled'){await client.query('ROLLBACK');return res.status(409).json({error:'Cancelled orders cannot be paid.'});}
    const existing=await client.query('SELECT * FROM demo_payments WHERE order_id=$1',[order.id]);
    if(existing.rowCount){await client.query('COMMIT');return res.json({payment:existing.rows[0],notice:'This is a simulated sandbox result only. No money was moved.'});}
    const reference='DEMO-'+crypto.randomBytes(6).toString('hex').toUpperCase();
    const result=await client.query("INSERT INTO demo_payments(order_id,customer_id,amount,status,reference) VALUES($1,$2,$3,'SIMULATED_SUCCESS',$4) RETURNING *",[order.id,req.session.user.id,order.total,reference]);
    await client.query('COMMIT');
    await audit(req.session.user.id,'demo_payment_simulated','demo_payment',reference,{orderId:order.public_id,amount:order.total});
    res.status(201).json({payment:result.rows[0],notice:'SIMULATION ONLY — no real payment was made and the order is not marked paid.'});
  } catch(e){await client.query('ROLLBACK');throw e;} finally{client.release();}
}));
api.get('/payments/demo/:orderId', requireAuth, asyncRoute(async(req,res)=>{
  const r=await pool.query('SELECT p.* FROM demo_payments p JOIN orders o ON o.id=p.order_id WHERE o.public_id=$1 AND o.customer_id=$2',[req.params.orderId,req.session.user.id]);
  res.json({payment:r.rows[0]||null,mode:'SANDBOX_ONLY'});
}));

api.get("/orders", requireAuth, asyncRoute(async (req,res) => {
  const seller = req.session.user.role === "seller";
  const admin = req.session.user.role === 'admin';
  const sql = admin ? `SELECT o.*,u.name AS customer_name,u.email AS customer_email FROM orders o JOIN users u ON u.id=o.customer_id ORDER BY o.created_at DESC` : seller
    ? `SELECT o.*,u.name AS customer_name,u.email AS customer_email FROM orders o JOIN users u ON u.id=o.customer_id WHERE o.seller_id=$1 ORDER BY o.created_at DESC`
    : `SELECT o.* FROM orders o WHERE o.customer_id=$1 ORDER BY o.created_at DESC`;
  const r = await pool.query(sql, (seller || !admin) ? [req.session.user.id] : []);
  res.json({orders:r.rows});
}));
api.patch("/orders/:id/status", requireAuth, asyncRoute(async (req,res) => {
  if(!['seller','admin'].includes(req.session.user.role)) return res.status(403).json({error:'Order management access required.'});
  const d = valid(z.object({ status:z.enum(["Pending verification","Payment verified","Fulfillment in progress","Completed","Cancelled"]) }), req.body);
  if(d.status === "Payment verified") return res.status(409).json({error:"Real payment gateway is not connected. Sandbox payment simulations cannot verify payment."});
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const current = await client.query(req.session.user.role==='admin' ? "SELECT * FROM orders WHERE public_id=$1 FOR UPDATE" : "SELECT * FROM orders WHERE public_id=$1 AND seller_id=$2 FOR UPDATE", req.session.user.role==='admin' ? [req.params.id] : [req.params.id,req.session.user.id]);
    if (!current.rowCount) { await client.query("ROLLBACK"); return res.status(404).json({error:"Order not found."}); }
    const old = current.rows[0];
    const allowed = {"Pending verification":["Payment verified","Cancelled"],"Payment verified":["Fulfillment in progress","Cancelled"],"Fulfillment in progress":["Completed","Cancelled"],"Completed":[],"Cancelled":[]};
    if (d.status !== old.status && !allowed[old.status].includes(d.status)) { await client.query('ROLLBACK'); return res.status(409).json({error:`Invalid status transition from ${old.status} to ${d.status}.`}); }
    if (old.status === "Cancelled" && d.status !== "Cancelled") {
      await client.query("ROLLBACK"); return res.status(409).json({error:"Cancelled orders cannot be reopened. Create a new order."});
    }
    if (d.status === "Cancelled" && old.status !== "Cancelled" && old.inventory_id) {
      await client.query("UPDATE inventory SET miles=miles+$1,updated_at=NOW() WHERE id=$2", [old.miles,old.inventory_id]);
    }
    const r = await client.query("UPDATE orders SET status=$1,updated_at=NOW() WHERE public_id=$2 RETURNING *", [d.status,req.params.id]);
    await client.query("COMMIT");
    await audit(req.session.user.id,'order_status_changed','order',req.params.id,{from:old.status,to:d.status});
    res.json({order:r.rows[0]});
  } catch(e) { await client.query("ROLLBACK"); throw e; }
  finally { client.release(); }
}));

api.get('/admin/overview', requireAdmin, asyncRoute(async(_req,res)=>{
  const [users,listings,orders,totals]=await Promise.all([
    pool.query("SELECT id,name,email,role,email_verified,seller_verified,created_at FROM users ORDER BY created_at DESC LIMIT 200"),
    pool.query("SELECT i.*,u.name AS seller_name,u.email AS seller_email FROM inventory i LEFT JOIN users u ON u.id=i.seller_id ORDER BY i.created_at DESC LIMIT 300"),
    pool.query("SELECT o.*,u.name AS customer_name,u.email AS customer_email FROM orders o JOIN users u ON u.id=o.customer_id ORDER BY o.created_at DESC LIMIT 300"),
    pool.query("SELECT (SELECT COUNT(*) FROM users) AS users,(SELECT COUNT(*) FROM inventory) AS listings,(SELECT COUNT(*) FROM orders) AS orders,(SELECT COUNT(*) FROM inventory WHERE review_status='pending') AS pending_listings")
  ]);
  res.json({users:users.rows,listings:listings.rows,orders:orders.rows,totals:totals.rows[0]});
}));
api.patch('/admin/users/:id/seller-verification', requireAdmin, asyncRoute(async(req,res)=>{
  const d=valid(z.object({verified:z.boolean()}),req.body);
  const r=await pool.query("UPDATE users SET seller_verified=$1 WHERE id=$2 AND role='seller' RETURNING id,email,seller_verified",[d.verified,req.params.id]);
  if(!r.rowCount)return res.status(404).json({error:'Seller account not found.'});
  await audit(req.session.user.id,d.verified?'seller_verified':'seller_verification_revoked','user',req.params.id);
  res.json({user:r.rows[0]});
}));
api.patch('/admin/listings/:id/review', requireAdmin, asyncRoute(async(req,res)=>{
  const d=valid(z.object({reviewStatus:z.enum(['approved','rejected','pending'])}),req.body);
  if(d.reviewStatus==='approved'){const check=await pool.query('SELECT i.seller_attested,u.seller_verified FROM inventory i JOIN users u ON u.id=i.seller_id WHERE i.id=$1',[req.params.id]);if(!check.rowCount)return res.status(404).json({error:'Listing not found.'});if(!check.rows[0].seller_attested||!check.rows[0].seller_verified)return res.status(409).json({error:'Seller verification and transfer-permission attestation are required before approval.'});}
  const r=await pool.query('UPDATE inventory SET review_status=$1,updated_at=NOW() WHERE id=$2 RETURNING id,program,review_status',[d.reviewStatus,req.params.id]);
  if(!r.rowCount)return res.status(404).json({error:'Listing not found.'});
  await audit(req.session.user.id,'listing_reviewed','inventory',req.params.id,{reviewStatus:d.reviewStatus});
  res.json({item:r.rows[0]});
}));
api.get('/admin/audit',requireAdmin,asyncRoute(async(_req,res)=>{const r=await pool.query('SELECT a.*,u.email AS actor_email FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.created_at DESC LIMIT 300');res.json({logs:r.rows});}));

app.use("/api", api);
app.use(express.static(path.join(__dirname,"public")));
app.get("*", (_req,res) => res.sendFile(path.join(__dirname,"public","index.html")));
app.use((err,_req,res,_next) => {
  console.error(err);
  res.status(err.status || 500).json({error: err.status ? err.message : "An unexpected server error occurred."});
});

const port = Number(process.env.PORT || 3000);
migrate().then(() => {
  const server=app.listen(port, () => console.log(`MilesHub listening on ${port}`));
  const shutdown=()=>server.close(async()=>{await pool.end();process.exit(0)});
  process.on('SIGTERM',shutdown); process.on('SIGINT',shutdown);
}).catch(err => { console.error("Database migration failed:",err); process.exit(1); });
